<?php

namespace App\Http\Controllers;

use App\Models\Sales;
use App\Models\NewSales;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CoffeeController extends Controller
{
    /**
     * Instantiate a new LoginRegisterController instance.
     */
    public function __construct()
    {
        $this->middleware('guest')->except([
            'salesdashboard',
        ]);
    }

    /**
     * Display a salesdashboard to authenticated users.
     *
     * @return \Illuminate\Http\Response
     */
    public function salesdashboard()
    {
        if (Auth::check()) {
            $previous_sales = Sales::all();

            return view('coffee_sales', compact('previous_sales'));
        }
        return redirect()->route('login')->withErrors([
            'email' => 'Please login to access the sales dashboard.'
        ])->onlyInput('email');
    }

    /**
     * Display a newsalesdashboard to authenticated users.
     *
     * @return \Illuminate\Http\Response
     */
    public function newsalesdashboard()
    {
        if (Auth::check()) {
            $previous_sales = NewSales::all();

            return view('new_coffee_sales.blade', compact('previous_sales'));
        }
    }

    public function newsale(Request $request)
    {
        $input = $request->all();
        $cost = $input['qty'] * $input['cost'];
        $selling_price = ($cost / (1 - 0.25)) + 10;
        //create the sales data
        Sales::create([
            'qty' => $input['qty'],
            'price' => $input['cost'],
            'selling_price' => round($selling_price, 2),
        ]);
        //get the all sales data
        $previous_sales = Sales::all();
        //return the response data
        return response()->json(['selling_price' => round($selling_price, 2), 'sale_data' => $previous_sales]);
    }

    public function newcoffeesale(Request $request)
    {
        $input = $request->all();
        $cost = $input['qty'] * $input['cost'];
        if ($input['productval'] == 1) {
            $profit = 1 - 0.25;
        } elseif ($input['productval'] == 2) {
            $profit = 1 - 0.15;
        }
        $selling_price = ($cost / $profit) + 10;
        //create the newsales
        NewSales::create([
            'product' => $input['productname'],
            'qty' => $input['qty'],
            'price' => $input['cost'],
            'selling_price' => round($selling_price, 2),
        ]);
        //get the new sales
        $previous_sales = NewSales::all();
        //get the response data
        return response()->json(['selling_price' => round($selling_price, 2), 'sale_data' => $previous_sales]);
    }
}