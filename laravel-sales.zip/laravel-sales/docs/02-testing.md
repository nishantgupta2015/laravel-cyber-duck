# TESTING

Please use the testing features that come with Laravel, feel free to use other tools you feel relevant
```
php artisan test
```