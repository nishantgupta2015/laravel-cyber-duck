# Local Data

Feel free to document local data you add.

We took the liberty of creating an initial Seeder with:
1. User for you to login:
   1. email: sales@coffee.shop
   2. password: password
