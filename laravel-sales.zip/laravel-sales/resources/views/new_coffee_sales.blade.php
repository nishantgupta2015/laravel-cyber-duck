<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('New ☕️ Sales') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                <div class="row justify-content-center mt-5">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">New Sales</div>
            <div class="card-body">
                @if ($message = Session::get('success'))
                    <div class="alert alert-success">
                        {{ $message }}
                    </div>
                @else
                    <div class="alert alert-success">
                        You are logged in!
                    </div>       
                @endif
                <form class="" id="submitform" method="post">
                    @csrf
                    Product
                    <select id="product">
                        <option value="1">Gold Coffee</option>
                        <option value="2">Arabic Coffee</option>
                    </select>
                    <br><br>
                    Quantity
                    <input type="text" id="qty" name="name">
                    <br><br>
                    Unit Cost (£)
                    <input type="text" id="cost" name="cost">
                    <br><br>
                    Selling Price
                    <input type="text" name="selling_price" id="selling_price" value="0">
                    <br><br>
                    <input type="submit" id="record_sale" name="submit" value="Record Sale">
                </form>
                Previous Sales
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">#</th> 
                            <th scope="col">Product</th>
                            <th scope="col">Quantity</th>
                            <th scope="col">Unit Cost</th>
                            <th scope="col">Selling Price</th>
                            <th scope="col">Sold at</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($previous_sales as $saleData)
                        <tr>
                            <th scope="row">{{ $saleData->id }}</th> 
                            <td>{{ $saleData->product }}</td>
                            <td>{{ $saleData->qty }}</td>
                            <td>{{ $saleData->price }}</td>
                            <td>{{ $saleData->selling_price }}</td>
                            <td>{{ $saleData->created_at }}</td>
                        </tr>
                        @endforeach
                    </tbody>
                </div></div></div></div></div></div></div></div>
            </x-app-layout>
            <!-- Jquery code -->
            <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
            <script>
                $(document).ready(function() {
                    $('#submitform').submit(function (event) {
                        event.preventDefault();
                        var productval = $("#product option:selected").val();
                        var productname = $("#product option:selected").text();
                        var qty = $("#qty").val();
                        var cost = $("#cost").val();
                        $.ajaxSetup({
                            headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')}
                        });
                        $.ajax({
                            type: "POST",
                            url: "{{ route('newcoffeesale') }}",
                            dataType: 'JSON',
                            cache: false,
                            data: {productname:productname, productval:productval,qty:qty, cost:cost},
                            success: function (data) {
                                $('#selling_price').val(data.selling_price);
                            },
                            error: function (jqXHR, textStatus, errorThrown) {
                                console.log(jqXHR.responseText + textStatus + " - " + errorThrown);
                            }
                        });
                    });
                });
            </script>