<?php

use App\Http\Controllers\CoffeeSalesController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return redirect()->route('login');
});
Route::controller(CoffeeController::class)->group(function () {
    Route::get('/salesdashboard', 'salesdashboard')->name('salesdashboard');
    Route::get('/newsalesdashboard', 'newsalesdashboard')->name('newsalesdashboard');
    Route::post('/newsale', 'newsale')->name('newsale');
    Route::post('/newcoffeesale', 'newcoffeesale')->name('newcoffeesale');
});
Route::redirect('/dashboard', '/sales');

Route::get('/sales', function () {
    return view('coffee_sales');
})->middleware(['auth'])->name('coffee.sales');

require __DIR__.'/auth.php';